﻿using Farragut.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverlayCalculation.Model
{
    public class Root
    {
        public OverlayTools OverlayTools { get; set; }
        public DataGridViewConfigurations DataGridViewConfigurations { get; set; }
        //public int Count { get; internal set; }
    }
}
