﻿using System.Collections.Generic;

namespace Farragut.Core
{
    public class DisplayColumns
    {
        public List<Column> Column { get; set; }

        //public  void Add(DataGridTextColumn dataGridTextColumn)
        //{
        //    throw new NotImplementedException();
        //}
        // public object Columns { get; internal set; }
    }
}