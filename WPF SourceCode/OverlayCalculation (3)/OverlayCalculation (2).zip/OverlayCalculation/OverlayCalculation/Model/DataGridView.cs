﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Farragut.Core
{
    public class DataGridView
    {
        public string FeatureClassName { get; set; }
        public string Name { get; set; }
        public string TabName { get; set; }
        public DisplayColumns DisplayColumns { get; set; }
    }
    //public class jsoncontrollist3
    //{
    //    public List<DataGridView> controls { get; set; }
    //}
}