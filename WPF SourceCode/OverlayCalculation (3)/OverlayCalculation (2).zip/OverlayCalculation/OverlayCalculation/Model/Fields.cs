﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Farragut.Core
{
    public class Fields
    {
        public string Field { get; set; }
    }
}