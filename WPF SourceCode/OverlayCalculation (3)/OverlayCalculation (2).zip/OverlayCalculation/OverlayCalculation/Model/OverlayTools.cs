﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Farragut.Core
{
    public class OverlayTools
    {
        public FormConfigurations FormConfigurations { get; set; }
    }
}